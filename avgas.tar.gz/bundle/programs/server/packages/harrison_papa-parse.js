(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Papa;

(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                     //
// packages/harrison:papa-parse/baby-parse.js                                                          //
//                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                       //
/*                                                                                                     // 1
    Baby Parse                                                                                         // 2
    v0.4.1                                                                                             // 3
    https://github.com/Rich-Harris/BabyParse                                                           // 4
                                                                                                       // 5
    Created by Rich Harris                                                                             // 6
    Maintained by Matt Holt                                                                            // 7
                                                                                                       // 8
    Based on Papa Parse v4.0.7 by Matt Holt                                                            // 9
    https://github.com/mholt/PapaParse                                                                 // 10
*/                                                                                                     // 11
                                                                                                       // 12
// A configuration object from which to draw default settings                                          // 13
var DEFAULTS = {                                                                                       // 14
    delimiter: "",  // empty: auto-detect                                                              // 15
    newline: "",    // empty: auto-detect                                                              // 16
    header: false,                                                                                     // 17
    dynamicTyping: false,                                                                              // 18
    preview: 0,                                                                                        // 19
    step: undefined,                                                                                   // 20
    comments: false,                                                                                   // 21
    complete: undefined,                                                                               // 22
    skipEmptyLines: false,                                                                             // 23
    fastMode: false                                                                                    // 24
};                                                                                                     // 25
                                                                                                       // 26
Papa = {};                                                                                             // 27
Papa.parse = CsvToJson;                                                                                // 28
Papa.parseFiles = ParseFiles;                                                                          // 29
Papa.unparse = JsonToCsv;                                                                              // 30
Papa.RECORD_SEP = String.fromCharCode(30);                                                             // 31
Papa.UNIT_SEP = String.fromCharCode(31);                                                               // 32
Papa.BYTE_ORDER_MARK = "\ufeff";                                                                       // 33
Papa.BAD_DELIMITERS = ["\r", "\n", "\"", Papa.BYTE_ORDER_MARK];                                        // 34
Papa.DefaultDelimiter = ",";        // Used if not specified and detection fails                       // 35
Papa.Parser = Parser;               // For testing/dev only                                            // 36
Papa.ParserHandle = ParserHandle;   // For testing/dev only                                            // 37
                                                                                                       // 38
function ParseFiles(_input, _config)                                                                   // 39
{                                                                                                      // 40
    if (Array.isArray(_input)) {                                                                       // 41
        var results = [];                                                                              // 42
        _input.forEach(function(input) {                                                               // 43
            if(typeof input === 'object')                                                              // 44
                results.push(ParseFiles(input.file, input.config));                                    // 45
            else                                                                                       // 46
                results.push(ParseFiles(input, _config));                                              // 47
        });                                                                                            // 48
        return results;                                                                                // 49
    } else {                                                                                           // 50
        var results = {                                                                                // 51
            data: [],                                                                                  // 52
            errors: []                                                                                 // 53
        };                                                                                             // 54
        if ((/(\.csv|\.txt)$/).test(_input)) {                                                         // 55
            try {                                                                                      // 56
                var contents = fs.readFileSync(_input).toString();                                     // 57
                return CsvToJson(contents, _config);                                                   // 58
            } catch (err) {                                                                            // 59
                results.errors.push(err);                                                              // 60
                return results;                                                                        // 61
            }                                                                                          // 62
        } else {                                                                                       // 63
            results.errors.push({                                                                      // 64
                type: '',                                                                              // 65
                code: '',                                                                              // 66
                message: 'Unsupported file type.',                                                     // 67
                row: ''                                                                                // 68
            });                                                                                        // 69
            return results;                                                                            // 70
        }                                                                                              // 71
    }                                                                                                  // 72
}                                                                                                      // 73
                                                                                                       // 74
function CsvToJson(_input, _config)                                                                    // 75
{                                                                                                      // 76
    var config = copyAndValidateConfig(_config);                                                       // 77
    var ph = new ParserHandle(config);                                                                 // 78
    var results = ph.parse(_input);                                                                    // 79
    if (isFunction(config.complete))                                                                   // 80
        config.complete(results);                                                                      // 81
    return results;                                                                                    // 82
}                                                                                                      // 83
                                                                                                       // 84
                                                                                                       // 85
                                                                                                       // 86
                                                                                                       // 87
function JsonToCsv(_input, _config)                                                                    // 88
{                                                                                                      // 89
    var _output = "";                                                                                  // 90
    var _fields = [];                                                                                  // 91
                                                                                                       // 92
    // Default configuration                                                                           // 93
    var _quotes = false;    // whether to surround every datum with quotes                             // 94
    var _delimiter = ",";   // delimiting character                                                    // 95
    var _newline = "\r\n";  // newline character(s)                                                    // 96
                                                                                                       // 97
    unpackConfig();                                                                                    // 98
                                                                                                       // 99
    if (typeof _input === 'string')                                                                    // 100
        _input = JSON.parse(_input);                                                                   // 101
                                                                                                       // 102
    if (_input instanceof Array)                                                                       // 103
    {                                                                                                  // 104
        if (!_input.length || _input[0] instanceof Array)                                              // 105
            return serialize(null, _input);                                                            // 106
        else if (typeof _input[0] === 'object')                                                        // 107
            return serialize(objectKeys(_input[0]), _input);                                           // 108
    }                                                                                                  // 109
    else if (typeof _input === 'object')                                                               // 110
    {                                                                                                  // 111
        if (typeof _input.data === 'string')                                                           // 112
            _input.data = JSON.parse(_input.data);                                                     // 113
                                                                                                       // 114
        if (_input.data instanceof Array)                                                              // 115
        {                                                                                              // 116
            if (!_input.fields)                                                                        // 117
                _input.fields = _input.data[0] instanceof Array                                        // 118
                                ? _input.fields                                                        // 119
                                : objectKeys(_input.data[0]);                                          // 120
                                                                                                       // 121
            if (!(_input.data[0] instanceof Array) && typeof _input.data[0] !== 'object')              // 122
                _input.data = [_input.data];    // handles input like [1,2,3] or ["asdf"]              // 123
        }                                                                                              // 124
                                                                                                       // 125
        return serialize(_input.fields || [], _input.data || []);                                      // 126
    }                                                                                                  // 127
                                                                                                       // 128
    // Default (any valid paths should return before this)                                             // 129
    throw "exception: Unable to serialize unrecognized input";                                         // 130
                                                                                                       // 131
                                                                                                       // 132
    function unpackConfig()                                                                            // 133
    {                                                                                                  // 134
        if (typeof _config !== 'object')                                                               // 135
            return;                                                                                    // 136
                                                                                                       // 137
        if (typeof _config.delimiter === 'string'                                                      // 138
            && _config.delimiter.length == 1                                                           // 139
            && Papa.BAD_DELIMITERS.indexOf(_config.delimiter) == -1)                                   // 140
        {                                                                                              // 141
            _delimiter = _config.delimiter;                                                            // 142
        }                                                                                              // 143
                                                                                                       // 144
        if (typeof _config.quotes === 'boolean'                                                        // 145
            || _config.quotes instanceof Array)                                                        // 146
            _quotes = _config.quotes;                                                                  // 147
                                                                                                       // 148
        if (typeof _config.newline === 'string')                                                       // 149
            _newline = _config.newline;                                                                // 150
    }                                                                                                  // 151
                                                                                                       // 152
                                                                                                       // 153
    // Turns an object's keys into an array                                                            // 154
    function objectKeys(obj)                                                                           // 155
    {                                                                                                  // 156
        if (typeof obj !== 'object')                                                                   // 157
            return [];                                                                                 // 158
        var keys = [];                                                                                 // 159
        for (var key in obj)                                                                           // 160
            keys.push(key);                                                                            // 161
        return keys;                                                                                   // 162
    }                                                                                                  // 163
                                                                                                       // 164
    // The double for loop that iterates the data and writes out a CSV string including header row     // 165
    function serialize(fields, data)                                                                   // 166
    {                                                                                                  // 167
        var csv = "";                                                                                  // 168
                                                                                                       // 169
        if (typeof fields === 'string')                                                                // 170
            fields = JSON.parse(fields);                                                               // 171
        if (typeof data === 'string')                                                                  // 172
            data = JSON.parse(data);                                                                   // 173
                                                                                                       // 174
        var hasHeader = fields instanceof Array && fields.length > 0;                                  // 175
        var dataKeyedByField = !(data[0] instanceof Array);                                            // 176
                                                                                                       // 177
        // If there a header row, write it first                                                       // 178
        if (hasHeader)                                                                                 // 179
        {                                                                                              // 180
            for (var i = 0; i < fields.length; i++)                                                    // 181
            {                                                                                          // 182
                if (i > 0)                                                                             // 183
                    csv += _delimiter;                                                                 // 184
                csv += safe(fields[i], i);                                                             // 185
            }                                                                                          // 186
            if (data.length > 0)                                                                       // 187
                csv += _newline;                                                                       // 188
        }                                                                                              // 189
                                                                                                       // 190
        // Then write out the data                                                                     // 191
        for (var row = 0; row < data.length; row++)                                                    // 192
        {                                                                                              // 193
            var maxCol = hasHeader ? fields.length : data[row].length;                                 // 194
                                                                                                       // 195
            for (var col = 0; col < maxCol; col++)                                                     // 196
            {                                                                                          // 197
                if (col > 0)                                                                           // 198
                    csv += _delimiter;                                                                 // 199
                var colIdx = hasHeader && dataKeyedByField ? fields[col] : col;                        // 200
                csv += safe(data[row][colIdx], col);                                                   // 201
            }                                                                                          // 202
                                                                                                       // 203
            if (row < data.length - 1)                                                                 // 204
                csv += _newline;                                                                       // 205
        }                                                                                              // 206
                                                                                                       // 207
        return csv;                                                                                    // 208
    }                                                                                                  // 209
                                                                                                       // 210
    // Encloses a value around quotes if needed (makes a value safe for CSV insertion)                 // 211
    function safe(str, col)                                                                            // 212
    {                                                                                                  // 213
        if (typeof str === "undefined" || str === null)                                                // 214
            return "";                                                                                 // 215
                                                                                                       // 216
        str = str.toString().replace(/"/g, '""');                                                      // 217
                                                                                                       // 218
        var needsQuotes = (typeof _quotes === 'boolean' && _quotes)                                    // 219
                        || (_quotes instanceof Array && _quotes[col])                                  // 220
                        || hasAny(str, Papa.BAD_DELIMITERS)                                            // 221
                        || str.indexOf(_delimiter) > -1                                                // 222
                        || str.charAt(0) == ' '                                                        // 223
                        || str.charAt(str.length - 1) == ' ';                                          // 224
                                                                                                       // 225
        return needsQuotes ? '"' + str + '"' : str;                                                    // 226
    }                                                                                                  // 227
                                                                                                       // 228
    function hasAny(str, substrings)                                                                   // 229
    {                                                                                                  // 230
        for (var i = 0; i < substrings.length; i++)                                                    // 231
            if (str.indexOf(substrings[i]) > -1)                                                       // 232
                return true;                                                                           // 233
        return false;                                                                                  // 234
    }                                                                                                  // 235
}                                                                                                      // 236
                                                                                                       // 237
                                                                                                       // 238
                                                                                                       // 239
                                                                                                       // 240
                                                                                                       // 241
                                                                                                       // 242
// Use one ParserHandle per entire CSV file or string                                                  // 243
function ParserHandle(_config)                                                                         // 244
{                                                                                                      // 245
    // One goal is to minimize the use of regular expressions...                                       // 246
    var FLOAT = /^\s*-?(\d*\.?\d+|\d+\.?\d*)(e[-+]?\d+)?\s*$/i;                                        // 247
                                                                                                       // 248
    var self = this;                                                                                   // 249
    var _stepCounter = 0;   // Number of times step was called (number of rows parsed)                 // 250
    var _input;             // The input being parsed                                                  // 251
    var _parser;            // The core parser being used                                              // 252
    var _paused = false;    // Whether we are paused or not                                            // 253
    var _delimiterError;    // Temporary state between delimiter detection and processing results      // 254
    var _fields = [];       // Fields are from the header row of the input, if there is one            // 255
    var _results = {        // The last results returned from the parser                               // 256
        data: [],                                                                                      // 257
        errors: [],                                                                                    // 258
        meta: {}                                                                                       // 259
    };                                                                                                 // 260
                                                                                                       // 261
    if (isFunction(_config.step))                                                                      // 262
    {                                                                                                  // 263
        var userStep = _config.step;                                                                   // 264
        _config.step = function(results)                                                               // 265
        {                                                                                              // 266
            _results = results;                                                                        // 267
                                                                                                       // 268
            if (needsHeaderRow())                                                                      // 269
                processResults();                                                                      // 270
            else    // only call user's step function after header row                                 // 271
            {                                                                                          // 272
                processResults();                                                                      // 273
                                                                                                       // 274
                // It's possbile that this line was empty and there's no row here after all            // 275
                if (_results.data.length == 0)                                                         // 276
                    return;                                                                            // 277
                                                                                                       // 278
                _stepCounter += results.data.length;                                                   // 279
                if (_config.preview && _stepCounter > _config.preview)                                 // 280
                    _parser.abort();                                                                   // 281
                else                                                                                   // 282
                    userStep(_results, self);                                                          // 283
            }                                                                                          // 284
        };                                                                                             // 285
    }                                                                                                  // 286
                                                                                                       // 287
    this.parse = function(input)                                                                       // 288
    {                                                                                                  // 289
        if (!_config.newline)                                                                          // 290
            _config.newline = guessLineEndings(input);                                                 // 291
                                                                                                       // 292
        _delimiterError = false;                                                                       // 293
        if (!_config.delimiter)                                                                        // 294
        {                                                                                              // 295
            var delimGuess = guessDelimiter(input);                                                    // 296
            if (delimGuess.successful)                                                                 // 297
                _config.delimiter = delimGuess.bestDelimiter;                                          // 298
            else                                                                                       // 299
            {                                                                                          // 300
                _delimiterError = true; // add error after parsing (otherwise it would be overwritten) // 301
                _config.delimiter = Papa.DefaultDelimiter;                                             // 302
            }                                                                                          // 303
            _results.meta.delimiter = _config.delimiter;                                               // 304
        }                                                                                              // 305
                                                                                                       // 306
        var parserConfig = copy(_config);                                                              // 307
        if (_config.preview && _config.header)                                                         // 308
            parserConfig.preview++; // to compensate for header row                                    // 309
                                                                                                       // 310
        _input = input;                                                                                // 311
        _parser = new Parser(parserConfig);                                                            // 312
        _results = _parser.parse(_input);                                                              // 313
        processResults();                                                                              // 314
        if (isFunction(_config.complete) && !_paused && (!self.streamer || self.streamer.finished()))  // 315
            _config.complete(_results);                                                                // 316
        return _paused ? { meta: { paused: true } } : (_results || { meta: { paused: false } });       // 317
    };                                                                                                 // 318
                                                                                                       // 319
    this.pause = function()                                                                            // 320
    {                                                                                                  // 321
        _paused = true;                                                                                // 322
        _parser.abort();                                                                               // 323
        _input = _input.substr(_parser.getCharIndex());                                                // 324
    };                                                                                                 // 325
                                                                                                       // 326
    this.resume = function()                                                                           // 327
    {                                                                                                  // 328
        _paused = false;                                                                               // 329
        _parser = new Parser(_config);                                                                 // 330
        _parser.parse(_input);                                                                         // 331
        if (!_paused)                                                                                  // 332
        {                                                                                              // 333
            if (self.streamer && !self.streamer.finished())                                            // 334
                self.streamer.resume();     // more of the file yet to come                            // 335
            else if (isFunction(_config.complete))                                                     // 336
                _config.complete(_results);                                                            // 337
        }                                                                                              // 338
    };                                                                                                 // 339
                                                                                                       // 340
    this.abort = function()                                                                            // 341
    {                                                                                                  // 342
        _parser.abort();                                                                               // 343
        if (isFunction(_config.complete))                                                              // 344
            _config.complete(_results);                                                                // 345
        _input = "";                                                                                   // 346
    };                                                                                                 // 347
                                                                                                       // 348
    function processResults()                                                                          // 349
    {                                                                                                  // 350
        if (_results && _delimiterError)                                                               // 351
        {                                                                                              // 352
            addError("Delimiter", "UndetectableDelimiter", "Unable to auto-detect delimiting character; defaulted to '"+Papa.DefaultDelimiter+"'");
            _delimiterError = false;                                                                   // 354
        }                                                                                              // 355
                                                                                                       // 356
        if (_config.skipEmptyLines)                                                                    // 357
        {                                                                                              // 358
            for (var i = 0; i < _results.data.length; i++)                                             // 359
                if (_results.data[i].length == 1 && _results.data[i][0] == "")                         // 360
                    _results.data.splice(i--, 1);                                                      // 361
        }                                                                                              // 362
                                                                                                       // 363
        if (needsHeaderRow())                                                                          // 364
            fillHeaderFields();                                                                        // 365
                                                                                                       // 366
        return applyHeaderAndDynamicTyping();                                                          // 367
    }                                                                                                  // 368
                                                                                                       // 369
    function needsHeaderRow()                                                                          // 370
    {                                                                                                  // 371
        return _config.header && _fields.length == 0;                                                  // 372
    }                                                                                                  // 373
                                                                                                       // 374
    function fillHeaderFields()                                                                        // 375
    {                                                                                                  // 376
        if (!_results)                                                                                 // 377
            return;                                                                                    // 378
        for (var i = 0; needsHeaderRow() && i < _results.data.length; i++)                             // 379
            for (var j = 0; j < _results.data[i].length; j++)                                          // 380
                _fields.push(_results.data[i][j]);                                                     // 381
        _results.data.splice(0, 1);                                                                    // 382
    }                                                                                                  // 383
                                                                                                       // 384
    function applyHeaderAndDynamicTyping()                                                             // 385
    {                                                                                                  // 386
        if (!_results || (!_config.header && !_config.dynamicTyping))                                  // 387
            return _results;                                                                           // 388
                                                                                                       // 389
        for (var i = 0; i < _results.data.length; i++)                                                 // 390
        {                                                                                              // 391
            var row = {};                                                                              // 392
                                                                                                       // 393
            for (var j = 0; j < _results.data[i].length; j++)                                          // 394
            {                                                                                          // 395
                if (_config.dynamicTyping)                                                             // 396
                {                                                                                      // 397
                    var value = _results.data[i][j];                                                   // 398
                    if (value == "true" || value === "TRUE")                                           // 399
                        _results.data[i][j] = true;                                                    // 400
                    else if (value == "false" || value === "FALSE")                                    // 401
                        _results.data[i][j] = false;                                                   // 402
                    else                                                                               // 403
                        _results.data[i][j] = tryParseFloat(value);                                    // 404
                }                                                                                      // 405
                                                                                                       // 406
                if (_config.header)                                                                    // 407
                {                                                                                      // 408
                    if (j >= _fields.length)                                                           // 409
                    {                                                                                  // 410
                        if (!row["__parsed_extra"])                                                    // 411
                            row["__parsed_extra"] = [];                                                // 412
                        row["__parsed_extra"].push(_results.data[i][j]);                               // 413
                    }                                                                                  // 414
                    else                                                                               // 415
                        row[_fields[j]] = _results.data[i][j];                                         // 416
                }                                                                                      // 417
            }                                                                                          // 418
                                                                                                       // 419
            if (_config.header)                                                                        // 420
            {                                                                                          // 421
                _results.data[i] = row;                                                                // 422
                if (j > _fields.length)                                                                // 423
                    addError("FieldMismatch", "TooManyFields", "Too many fields: expected " + _fields.length + " fields but parsed " + j, i);
                else if (j < _fields.length)                                                           // 425
                    addError("FieldMismatch", "TooFewFields", "Too few fields: expected " + _fields.length + " fields but parsed " + j, i);
            }                                                                                          // 427
        }                                                                                              // 428
                                                                                                       // 429
        if (_config.header && _results.meta)                                                           // 430
            _results.meta.fields = _fields;                                                            // 431
        return _results;                                                                               // 432
    }                                                                                                  // 433
                                                                                                       // 434
    function guessDelimiter(input)                                                                     // 435
    {                                                                                                  // 436
        var delimChoices = [",", "\t", "|", ";", Papa.RECORD_SEP, Papa.UNIT_SEP];                      // 437
        var bestDelim, bestDelta, fieldCountPrevRow;                                                   // 438
                                                                                                       // 439
        for (var i = 0; i < delimChoices.length; i++)                                                  // 440
        {                                                                                              // 441
            var delim = delimChoices[i];                                                               // 442
            var delta = 0, avgFieldCount = 0;                                                          // 443
            fieldCountPrevRow = undefined;                                                             // 444
                                                                                                       // 445
            var preview = new Parser({                                                                 // 446
                delimiter: delim,                                                                      // 447
                preview: 10                                                                            // 448
            }).parse(input);                                                                           // 449
                                                                                                       // 450
            for (var j = 0; j < preview.data.length; j++)                                              // 451
            {                                                                                          // 452
                var fieldCount = preview.data[j].length;                                               // 453
                avgFieldCount += fieldCount;                                                           // 454
                                                                                                       // 455
                if (typeof fieldCountPrevRow === 'undefined')                                          // 456
                {                                                                                      // 457
                    fieldCountPrevRow = fieldCount;                                                    // 458
                    continue;                                                                          // 459
                }                                                                                      // 460
                else if (fieldCount > 1)                                                               // 461
                {                                                                                      // 462
                    delta += Math.abs(fieldCount - fieldCountPrevRow);                                 // 463
                    fieldCountPrevRow = fieldCount;                                                    // 464
                }                                                                                      // 465
            }                                                                                          // 466
                                                                                                       // 467
            avgFieldCount /= preview.data.length;                                                      // 468
                                                                                                       // 469
            if ((typeof bestDelta === 'undefined' || delta < bestDelta)                                // 470
                && avgFieldCount > 1.99)                                                               // 471
            {                                                                                          // 472
                bestDelta = delta;                                                                     // 473
                bestDelim = delim;                                                                     // 474
            }                                                                                          // 475
        }                                                                                              // 476
                                                                                                       // 477
        _config.delimiter = bestDelim;                                                                 // 478
                                                                                                       // 479
        return {                                                                                       // 480
            successful: !!bestDelim,                                                                   // 481
            bestDelimiter: bestDelim                                                                   // 482
        }                                                                                              // 483
    }                                                                                                  // 484
                                                                                                       // 485
    function guessLineEndings(input)                                                                   // 486
    {                                                                                                  // 487
        input = input.substr(0, 1024*1024); // max length 1 MB                                         // 488
                                                                                                       // 489
        var r = input.split('\r');                                                                     // 490
                                                                                                       // 491
        if (r.length == 1)                                                                             // 492
            return '\n';                                                                               // 493
                                                                                                       // 494
        var numWithN = 0;                                                                              // 495
        for (var i = 0; i < r.length; i++)                                                             // 496
        {                                                                                              // 497
            if (r[i][0] == '\n')                                                                       // 498
                numWithN++;                                                                            // 499
        }                                                                                              // 500
                                                                                                       // 501
        return numWithN >= r.length / 2 ? '\r\n' : '\r';                                               // 502
    }                                                                                                  // 503
                                                                                                       // 504
    function tryParseFloat(val)                                                                        // 505
    {                                                                                                  // 506
        var isNumber = FLOAT.test(val);                                                                // 507
        return isNumber ? parseFloat(val) : val;                                                       // 508
    }                                                                                                  // 509
                                                                                                       // 510
    function addError(type, code, msg, row)                                                            // 511
    {                                                                                                  // 512
        _results.errors.push({                                                                         // 513
            type: type,                                                                                // 514
            code: code,                                                                                // 515
            message: msg,                                                                              // 516
            row: row                                                                                   // 517
        });                                                                                            // 518
    }                                                                                                  // 519
}                                                                                                      // 520
                                                                                                       // 521
                                                                                                       // 522
                                                                                                       // 523
                                                                                                       // 524
                                                                                                       // 525
                                                                                                       // 526
// The core parser implements speedy and correct CSV parsing                                           // 527
function Parser(config)                                                                                // 528
{                                                                                                      // 529
    // Unpack the config object                                                                        // 530
    config = config || {};                                                                             // 531
    var delim = config.delimiter;                                                                      // 532
    var newline = config.newline;                                                                      // 533
    var comments = config.comments;                                                                    // 534
    var step = config.step;                                                                            // 535
    var preview = config.preview;                                                                      // 536
    var fastMode = config.fastMode;                                                                    // 537
                                                                                                       // 538
    // Delimiter must be valid                                                                         // 539
    if (typeof delim !== 'string'                                                                      // 540
        || delim.length != 1                                                                           // 541
        || Papa.BAD_DELIMITERS.indexOf(delim) > -1)                                                    // 542
        delim = ",";                                                                                   // 543
                                                                                                       // 544
    // Comment character must be valid                                                                 // 545
    if (comments === delim)                                                                            // 546
        throw "Comment character same as delimiter";                                                   // 547
    else if (comments === true)                                                                        // 548
        comments = "#";                                                                                // 549
    else if (typeof comments !== 'string'                                                              // 550
        || Papa.BAD_DELIMITERS.indexOf(comments) > -1)                                                 // 551
        comments = false;                                                                              // 552
                                                                                                       // 553
    // Newline must be valid: \r, \n, or \r\n                                                          // 554
    if (newline != '\n' && newline != '\r' && newline != '\r\n')                                       // 555
        newline = '\n';                                                                                // 556
                                                                                                       // 557
    // We're gonna need these at the Parser scope                                                      // 558
    var cursor = 0;                                                                                    // 559
    var aborted = false;                                                                               // 560
                                                                                                       // 561
    this.parse = function(input)                                                                       // 562
    {                                                                                                  // 563
        // For some reason, in Chrome, this speeds things up (!?)                                      // 564
        if (typeof input !== 'string')                                                                 // 565
            throw "Input must be a string";                                                            // 566
                                                                                                       // 567
        // We don't need to compute some of these every time parse() is called,                        // 568
        // but having them in a more local scope seems to perform better                               // 569
        var inputLen = input.length,                                                                   // 570
            delimLen = delim.length,                                                                   // 571
            newlineLen = newline.length,                                                               // 572
            commentsLen = comments.length;                                                             // 573
        var stepIsFunction = typeof step === 'function';                                               // 574
                                                                                                       // 575
        // Establish starting state                                                                    // 576
        cursor = 0;                                                                                    // 577
        var data = [], errors = [], row = [];                                                          // 578
                                                                                                       // 579
        if (!input)                                                                                    // 580
            return returnable();                                                                       // 581
                                                                                                       // 582
        if (fastMode)                                                                                  // 583
        {                                                                                              // 584
            // Fast mode assumes there are no quoted fields in the input                               // 585
            var rows = input.split(newline);                                                           // 586
            for (var i = 0; i < rows.length; i++)                                                      // 587
            {                                                                                          // 588
                if (comments && rows[i].substr(0, commentsLen) == comments)                            // 589
                    continue;                                                                          // 590
                if (stepIsFunction)                                                                    // 591
                {                                                                                      // 592
                    data = [ rows[i].split(delim) ];                                                   // 593
                    doStep();                                                                          // 594
                    if (aborted)                                                                       // 595
                        return returnable();                                                           // 596
                }                                                                                      // 597
                else                                                                                   // 598
                    data.push(rows[i].split(delim));                                                   // 599
                if (preview && i >= preview)                                                           // 600
                {                                                                                      // 601
                    data = data.slice(0, preview);                                                     // 602
                    return returnable(true);                                                           // 603
                }                                                                                      // 604
            }                                                                                          // 605
            return returnable();                                                                       // 606
        }                                                                                              // 607
                                                                                                       // 608
        var nextDelim = input.indexOf(delim, cursor);                                                  // 609
        var nextNewline = input.indexOf(newline, cursor);                                              // 610
                                                                                                       // 611
        // Parser loop                                                                                 // 612
        for (;;)                                                                                       // 613
        {                                                                                              // 614
            // Field has opening quote                                                                 // 615
            if (input[cursor] == '"')                                                                  // 616
            {                                                                                          // 617
                // Start our search for the closing quote where the cursor is                          // 618
                var quoteSearch = cursor;                                                              // 619
                                                                                                       // 620
                // Skip the opening quote                                                              // 621
                cursor++;                                                                              // 622
                                                                                                       // 623
                for (;;)                                                                               // 624
                {                                                                                      // 625
                    // Find closing quote                                                              // 626
                    var quoteSearch = input.indexOf('"', quoteSearch+1);                               // 627
                                                                                                       // 628
                    if (quoteSearch === -1)                                                            // 629
                    {                                                                                  // 630
                        // No closing quote... what a pity                                             // 631
                        errors.push({                                                                  // 632
                            type: "Quotes",                                                            // 633
                            code: "MissingQuotes",                                                     // 634
                            message: "Quoted field unterminated",                                      // 635
                            row: data.length,   // row has yet to be inserted                          // 636
                            index: cursor                                                              // 637
                        });                                                                            // 638
                        return finish();                                                               // 639
                    }                                                                                  // 640
                                                                                                       // 641
                    if (quoteSearch === inputLen-1)                                                    // 642
                    {                                                                                  // 643
                        // Closing quote at EOF                                                        // 644
                        row.push(input.substring(cursor, quoteSearch).replace(/""/g, '"'));            // 645
                        data.push(row);                                                                // 646
                        if (stepIsFunction)                                                            // 647
                            doStep();                                                                  // 648
                        return returnable();                                                           // 649
                    }                                                                                  // 650
                                                                                                       // 651
                    // If this quote is escaped, it's part of the data; skip it                        // 652
                    if (input[quoteSearch+1] == '"')                                                   // 653
                    {                                                                                  // 654
                        quoteSearch++;                                                                 // 655
                        continue;                                                                      // 656
                    }                                                                                  // 657
                                                                                                       // 658
                    if (input[quoteSearch+1] == delim)                                                 // 659
                    {                                                                                  // 660
                        // Closing quote followed by delimiter                                         // 661
                        row.push(input.substring(cursor, quoteSearch).replace(/""/g, '"'));            // 662
                        cursor = quoteSearch + 1 + delimLen;                                           // 663
                        nextDelim = input.indexOf(delim, cursor);                                      // 664
                        nextNewline = input.indexOf(newline, cursor);                                  // 665
                        break;                                                                         // 666
                    }                                                                                  // 667
                                                                                                       // 668
                    if (input.substr(quoteSearch+1, newlineLen) === newline)                           // 669
                    {                                                                                  // 670
                        // Closing quote followed by newline                                           // 671
                        row.push(input.substring(cursor, quoteSearch).replace(/""/g, '"'));            // 672
                        saveRow(quoteSearch + 1 + newlineLen);                                         // 673
                        nextDelim = input.indexOf(delim, cursor);   // because we may have skipped the nextDelim in the quoted field
                                                                                                       // 675
                        if (stepIsFunction)                                                            // 676
                        {                                                                              // 677
                            doStep();                                                                  // 678
                            if (aborted)                                                               // 679
                                return returnable();                                                   // 680
                        }                                                                              // 681
                                                                                                       // 682
                        if (preview && data.length >= preview)                                         // 683
                            return returnable(true);                                                   // 684
                                                                                                       // 685
                        break;                                                                         // 686
                    }                                                                                  // 687
                }                                                                                      // 688
                                                                                                       // 689
                continue;                                                                              // 690
            }                                                                                          // 691
                                                                                                       // 692
            // Comment found at start of new line                                                      // 693
            if (comments && row.length === 0 && input.substr(cursor, commentsLen) === comments)        // 694
            {                                                                                          // 695
                if (nextNewline == -1)  // Comment ends at EOF                                         // 696
                    return returnable();                                                               // 697
                cursor = nextNewline + newlineLen;                                                     // 698
                nextNewline = input.indexOf(newline, cursor);                                          // 699
                nextDelim = input.indexOf(delim, cursor);                                              // 700
                continue;                                                                              // 701
            }                                                                                          // 702
                                                                                                       // 703
            // Next delimiter comes before next newline, so we've reached end of field                 // 704
            if (nextDelim !== -1 && (nextDelim < nextNewline || nextNewline === -1))                   // 705
            {                                                                                          // 706
                row.push(input.substring(cursor, nextDelim));                                          // 707
                cursor = nextDelim + delimLen;                                                         // 708
                nextDelim = input.indexOf(delim, cursor);                                              // 709
                continue;                                                                              // 710
            }                                                                                          // 711
                                                                                                       // 712
            // End of row                                                                              // 713
            if (nextNewline !== -1)                                                                    // 714
            {                                                                                          // 715
                row.push(input.substring(cursor, nextNewline));                                        // 716
                saveRow(nextNewline + newlineLen);                                                     // 717
                                                                                                       // 718
                if (stepIsFunction)                                                                    // 719
                {                                                                                      // 720
                    doStep();                                                                          // 721
                    if (aborted)                                                                       // 722
                        return returnable();                                                           // 723
                }                                                                                      // 724
                                                                                                       // 725
                if (preview && data.length >= preview)                                                 // 726
                    return returnable(true);                                                           // 727
                                                                                                       // 728
                continue;                                                                              // 729
            }                                                                                          // 730
                                                                                                       // 731
            break;                                                                                     // 732
        }                                                                                              // 733
                                                                                                       // 734
                                                                                                       // 735
        return finish();                                                                               // 736
                                                                                                       // 737
                                                                                                       // 738
        // Appends the remaining input from cursor to the end into                                     // 739
        // row, saves the row, calls step, and returns the results.                                    // 740
        function finish()                                                                              // 741
        {                                                                                              // 742
            row.push(input.substr(cursor));                                                            // 743
            data.push(row);                                                                            // 744
            cursor = inputLen;  // important in case parsing is paused                                 // 745
            if (stepIsFunction)                                                                        // 746
                doStep();                                                                              // 747
            return returnable();                                                                       // 748
        }                                                                                              // 749
                                                                                                       // 750
        // Appends the current row to the results. It sets the cursor                                  // 751
        // to newCursor and finds the nextNewline. The caller should                                   // 752
        // take care to execute user's step function and check for                                     // 753
        // preview and end parsing if necessary.                                                       // 754
        function saveRow(newCursor)                                                                    // 755
        {                                                                                              // 756
            data.push(row);                                                                            // 757
            row = [];                                                                                  // 758
            cursor = newCursor;                                                                        // 759
            nextNewline = input.indexOf(newline, cursor);                                              // 760
        }                                                                                              // 761
                                                                                                       // 762
        // Returns an object with the results, errors, and meta.                                       // 763
        function returnable(stopped)                                                                   // 764
        {                                                                                              // 765
            return {                                                                                   // 766
                data: data,                                                                            // 767
                errors: errors,                                                                        // 768
                meta: {                                                                                // 769
                    delimiter: delim,                                                                  // 770
                    linebreak: newline,                                                                // 771
                    aborted: aborted,                                                                  // 772
                    truncated: !!stopped                                                               // 773
                }                                                                                      // 774
            };                                                                                         // 775
        }                                                                                              // 776
                                                                                                       // 777
        // Executes the user's step function and resets data & errors.                                 // 778
        function doStep()                                                                              // 779
        {                                                                                              // 780
            step(returnable());                                                                        // 781
            data = [], errors = [];                                                                    // 782
        }                                                                                              // 783
    };                                                                                                 // 784
                                                                                                       // 785
    // Sets the abort flag                                                                             // 786
    this.abort = function()                                                                            // 787
    {                                                                                                  // 788
        aborted = true;                                                                                // 789
    };                                                                                                 // 790
                                                                                                       // 791
    // Gets the cursor position                                                                        // 792
    this.getCharIndex = function()                                                                     // 793
    {                                                                                                  // 794
        return cursor;                                                                                 // 795
    };                                                                                                 // 796
}                                                                                                      // 797
                                                                                                       // 798
                                                                                                       // 799
                                                                                                       // 800
                                                                                                       // 801
// Replaces bad config values with good, default ones                                                  // 802
function copyAndValidateConfig(origConfig)                                                             // 803
{                                                                                                      // 804
    if (typeof origConfig !== 'object')                                                                // 805
        origConfig = {};                                                                               // 806
                                                                                                       // 807
    var config = copy(origConfig);                                                                     // 808
                                                                                                       // 809
    if (typeof config.delimiter !== 'string'                                                           // 810
        || config.delimiter.length != 1                                                                // 811
        || Papa.BAD_DELIMITERS.indexOf(config.delimiter) > -1)                                         // 812
        config.delimiter = DEFAULTS.delimiter;                                                         // 813
                                                                                                       // 814
    if (config.newline != '\n'                                                                         // 815
        && config.newline != '\r'                                                                      // 816
        && config.newline != '\r\n')                                                                   // 817
        config.newline = DEFAULTS.newline;                                                             // 818
                                                                                                       // 819
    if (typeof config.header !== 'boolean')                                                            // 820
        config.header = DEFAULTS.header;                                                               // 821
                                                                                                       // 822
    if (typeof config.dynamicTyping !== 'boolean')                                                     // 823
        config.dynamicTyping = DEFAULTS.dynamicTyping;                                                 // 824
                                                                                                       // 825
    if (typeof config.preview !== 'number')                                                            // 826
        config.preview = DEFAULTS.preview;                                                             // 827
                                                                                                       // 828
    if (typeof config.step !== 'function')                                                             // 829
        config.step = DEFAULTS.step;                                                                   // 830
                                                                                                       // 831
    if (typeof config.complete !== 'function')                                                         // 832
        config.complete = DEFAULTS.complete;                                                           // 833
                                                                                                       // 834
    if (typeof config.skipEmptyLines !== 'boolean')                                                    // 835
        config.skipEmptyLines = DEFAULTS.skipEmptyLines;                                               // 836
                                                                                                       // 837
    if (typeof config.fastMode !== 'boolean')                                                          // 838
        config.fastMode = DEFAULTS.fastMode;                                                           // 839
                                                                                                       // 840
    return config;                                                                                     // 841
}                                                                                                      // 842
                                                                                                       // 843
function copy(obj)                                                                                     // 844
{                                                                                                      // 845
    if (typeof obj !== 'object')                                                                       // 846
        return obj;                                                                                    // 847
    var cpy = obj instanceof Array ? [] : {};                                                          // 848
    for (var key in obj)                                                                               // 849
        cpy[key] = copy(obj[key]);                                                                     // 850
    return cpy;                                                                                        // 851
}                                                                                                      // 852
                                                                                                       // 853
function isFunction(func)                                                                              // 854
{                                                                                                      // 855
    return typeof func === 'function';                                                                 // 856
}                                                                                                      // 857
                                                                                                       // 858
                                                                                                       // 859
/////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['harrison:papa-parse'] = {
  Papa: Papa
};

})();

//# sourceMappingURL=harrison_papa-parse.js.map
